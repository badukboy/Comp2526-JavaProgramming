package A00580605.lab.data;

@SuppressWarnings("serial")
public class NotAnIntegerException extends Exception{

	public NotAnIntegerException(String string) {
		super(string);
	}

}
