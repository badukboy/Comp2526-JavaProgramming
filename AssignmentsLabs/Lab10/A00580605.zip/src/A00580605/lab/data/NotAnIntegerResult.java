package A00580605.lab.data;

public class NotAnIntegerResult extends Exception{

	public NotAnIntegerResult(String string) {
		super(string);
	}

}
