package A00580605.lab.data;

public class DivideByZeroException extends Exception{
	public DivideByZeroException(String string) {
		super(string);
	}
}
