package A00580605.lab;

import java.io.FileNotFoundException;

import A00580605.lab.ui.AppFrame;

public class Lab9 {
	public static void main(String[] args) throws FileNotFoundException{
		new AppFrame().setVisible(true);
	}
}
