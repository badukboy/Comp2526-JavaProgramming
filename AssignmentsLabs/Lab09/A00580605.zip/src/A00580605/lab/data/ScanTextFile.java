package A00580605.lab.data;

import java.io.FileNotFoundException;

public interface ScanTextFile {
	public Object[] readTextData() throws FileNotFoundException;
}
