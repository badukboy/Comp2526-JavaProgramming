package A00580605.lab.data;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public interface ScanTextFile {
	public Object[] readTextData() throws FileNotFoundException;
}
