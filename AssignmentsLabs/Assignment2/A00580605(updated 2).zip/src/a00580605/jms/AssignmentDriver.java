package a00580605.jms;

import java.io.FileNotFoundException;

import a00580605.jms.ui.JMSFrame;

public class AssignmentDriver {
	public static void main(String[] args) throws FileNotFoundException{
		new JMSFrame().setVisible(true);
	}
}
